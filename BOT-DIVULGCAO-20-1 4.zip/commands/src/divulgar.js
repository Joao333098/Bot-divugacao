const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./database/usuarios.json" });
const config = new JsonDatabase({ databasePath: "./database/configurações.json" });
const cnfg = require("../../configs/config.json");

module.exports = {
  name: "divulgar",
  aliases: ["div"],

  run: async (client, message, args) => {
    const msgContent = args.join(' ');

    if (message.author.id !== `${cnfg.owner}`) {
      return message.reply(`Sai fora, pilantra! Se é o dono do bot, não! Caso queira um igual [aperte aqui](https://discord.gg/uH8YWhNK7e)`)
        .then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
    }

    if (!msgContent) {
      return message.channel.send('? Faltou o texto aí, man! Usa !divulgar (texto)');
    }

    const guilds = config.get("servidor");
    const guild = client.guilds.cache.get(guilds);

    if (!guild) {
      return message.reply('Ei, o servidor para eu divulgar aqui eu não achei. Ajeita essa bomba aí! Se não me engano, você pode utilizar o comando !setservidor para isso.');
    }

    try {
      await guild.members.fetch();
    } catch (error) {
      console.error('Erro ao buscar membros do servidor:', error.message);
      return message.reply('Ocorreu um erro ao buscar membros do servidor.');
    }

    const todos = Array.from(guild.members.cache.values()).filter(member => {
      return !member.user.bot && !db.has(`${member.user.id}_div`);
    });

    if (todos.length === 0) {
      return message.reply({ content: `Ops... não posso mandar mensagem para ninguém, Zé. Já enviei para todos, todas e todes 😂` });
    } else {
      const sentMessage = await message.channel.send('Iniciando processo de divulgação...');
      for (let index = 0; index < todos.length; index++) {
        const member = todos[index];
        try {
          await new Promise(resolve => setTimeout(resolve, 2000)); 
          await member.send(msgContent);
          console.log(`${member.user.username} recebeu - ${index + 1}/${todos.length}`);
          db.set(`${member.user.id}_div`, "saas");
     
          await sentMessage.edit(`Ligando meu sisteminha para ${member.user.username} - ${index + 1}/${todos.length}`);
        } catch (error) {
          console.error(`${member.user.username} não recebeu - ${index + 1}/${todos.length}: ${error.message}`);
          db.set(`${member.user.id}_div`, "saas");
        }
      }
   
      await sentMessage.edit(`Processo de divulgação concluído! Mensagens enviadas para ${todos.length} membros.`);
    }
  }
};
