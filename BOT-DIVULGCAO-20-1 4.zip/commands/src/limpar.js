const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./database/usuarios.json" });
const config = new JsonDatabase({ databasePath: "./database/configurações.json" });
const cnfg = require("../../configs/config.json");
module.exports = {
  name: "limpar",
  aliases: ["deletar"],

  run: async (client, message, args) => {
    if(message.author.id !== `${cnfg.owner}`) return message.reply(`sai fora pilantra se é o dono do bot n caso queira um igual [aperte aqui](https://discord.gg/uH8YWhNK7e)`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
db.deleteAll();
message.reply({content: `Limpo com sucesso!`})
  }
}